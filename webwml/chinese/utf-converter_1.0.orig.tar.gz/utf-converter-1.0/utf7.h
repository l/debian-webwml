#include <stdio.h>

extern	long	utf7_getc(
#ifdef __STDC__
			FILE *f
#endif
		);

extern	void	utf7_putc(
#ifdef __STDC__
	unsigned int	c,
	FILE *f
#endif
		);
