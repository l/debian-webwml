/*
u7touni.c -- convert utf7 to double-byte unicode.
usage:	u7touni infile outfile
		<infile> utf7 file
		<outfile> binary unicode file
note:	it is NOT an unix filter.
author: Guo Jin (guojin@iss.nus.sg)
date:	Nov. 10, 1994
see also: the utf7 package by Ross Paterson <rap@doc.ic.ac.uk> ftped from
	ifcss.org: /software/unix/convert
*/

#include <stdio.h>
#include "utf7.h"

int
main(argc, argv)
int argc;
char *argv[];
{
	FILE	*ifp, *ofp;
	unsigned short	unichar;

	if (argc != 3) {
		printf("usage: u7touni <infile> <outfile>\n");
		exit(0);
	}

	ifp = fopen(argv[1], "r");
	if (ifp == NULL) {
		printf("infile <%s> not found!\n", argv[1]);
		exit(0);
	}

	ofp = fopen(argv[2], "wb");
	if (ofp == NULL) {
		printf("cannot open outfile <%s>!\n", argv[2]);
		exit(0);
	}

	while ((unichar = utf7_getc(ifp)) != (unsigned short)EOF) {
		fwrite(&unichar, sizeof(unsigned short), 1, ofp);
	}

	fclose(ifp);
	fclose(ofp);

	return 0;
}
