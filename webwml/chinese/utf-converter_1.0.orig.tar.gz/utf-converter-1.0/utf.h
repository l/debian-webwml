#include <stdio.h>

typedef	long	Char;

/* The UTF-FSS (aka UTF-2) encoding of ISO-10646/Unicode */

Char	utf_getc(
#ifdef	__STDC__
		FILE *f
#endif
);
Char	utf_putc(
#ifdef	__STDC__
	Char c, FILE *f
#endif
);

#define	utf_getchar()	utf_getc(stdin)
#define	utf_putchar(wc)	utf_putc((wc),stdout)
