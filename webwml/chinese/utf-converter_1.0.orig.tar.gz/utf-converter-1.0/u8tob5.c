#include "utf.h"

extern	unsigned short	b5_out[];

int
main()
{
	long	c;
	unsigned int	b5;

	while ((c = utf_getc(stdin)) != EOF)
		if (c < 0x80)
			putchar((int)c);
		else {
			b5 = b5_out[c];
			putchar(b5 >> 8);
			putchar(b5 & 0xff);
		}
	return 0;
}
