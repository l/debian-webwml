/*
chtchs.to.gb_out -- convert the cht-to-chs conversion table (in utf8)
to a c program gb_out.c

author: Guo Jin (guojin@iss.nus.sg)
date: Nov. 10, 1994
usage: chtchs.to.gb_out < chtchs.u8 > gb_out.c
see also: the utf7 package by Ross Paterson <rap@doc.ic.ac.uk> ftped from
	ifcss.org: /software/unix/convert
*/

#include "utf.h"
#define	UNDEF	0xA1F5

extern unsigned short	gb_out[];

int
main()
{
	unsigned short	c;
	unsigned short	cht;
	int	first_cht, first_chs;
	int	i, j;

	/*--- add chtchs.u8 data to gb_out[] ---*/
	cht=UNDEF; first_cht=1; first_chs=1;
	while ((c = utf_getc(stdin)) != (unsigned short)EOF) {
		if (c == 0x0a) {
			first_cht=1; first_chs=1;
		} else if (c < 0x80) {
		} else {
			if (first_cht) { cht=c; first_cht=0; }
			else if (first_chs) {
				gb_out[cht]=gb_out[c]; first_chs=0;
			}
		}
	}

	/*--- generate c rpogram gb_out.c ---*/
	printf("#define		UNDEF	0x%4X\n", UNDEF);
	printf("\n");
	printf("unsigned short gb_out[] = {\n");
	for(i=0; i<0x10000; i+=0x08) {
		printf("\t");
		for(j=0; j<0x08; j++) {
			if (gb_out[i+j] == UNDEF) {
				printf("UNDEF");
			} else {
				printf("0x%4X", gb_out[i+j]);
			}
			if (i+j!=0xffff) printf(",");
			if (j!=0x07) printf("\t");
		}
		printf("\n");
	}
	printf("};\n");

	return 0;
}
