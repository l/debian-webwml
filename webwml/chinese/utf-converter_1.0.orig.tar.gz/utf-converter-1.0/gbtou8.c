#include "utf.h"

extern	unsigned short	gb_in[];

int
main()
{
	int	c1, c2;

	while ((c1 = getchar()) != EOF)
		if ((c1&0x80) == 0)
			utf_putc(c1, stdout);
		else {
			if ((c2 = getchar()) == EOF)
				break;
			utf_putc(gb_in[(c1 - 0xa1)*94 + (c2&0x7f) - 0x21],
				stdout);
		}
	return 0;
}
