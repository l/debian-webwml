#include "utf7.h"
#include "utf.h"

int
main()
{
	Char	c;

	while ((c = utf_getc(stdin)) != EOF)
		utf7_putc((unsigned)c, stdout);
	return 0;
}
