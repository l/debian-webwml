#include "utf7.h"
#include "utf.h"

int
main()
{
	Char	c;

	while ((c = utf7_getc(stdin)) != EOF)
		utf_putc(c, stdout);
	return 0;
}
