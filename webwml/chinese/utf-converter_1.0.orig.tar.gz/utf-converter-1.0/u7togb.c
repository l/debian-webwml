#include "utf7.h"

extern	unsigned short	gb_out[];

int
main()
{
	long	c;
	unsigned int	gb;

	while ((c = utf7_getc(stdin)) != EOF)
		if (c < 0x80)
			putchar((int)c);
		else {
			gb = gb_out[c];
			putchar(gb >> 8);
			putchar(gb & 0xff);
		}
	return 0;
}
