#include "utf.h"

extern	unsigned short	b5_in[];

int
main()
{
	int	c1, c2;

	while ((c1 = getchar()) != EOF)
		if ((c1&0x80) == 0)
			utf_putc(c1, stdout);
		else {
			if ((c2 = getchar()) == EOF)
				break;
			c2 -= c2 >= 0xa1 ? (0xa1 - 63) : 0x40;
			utf_putc(b5_in[(c1 - 0xa1)*157 + c2], stdout);
		}
	return 0;
}
