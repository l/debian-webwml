/*
unitou8.c -- ocnvert double-byte unicode to utf8.
usage:	unitou8 infile outfile
		<infile> binary unicode file.
		<outfile> utf8 file.
note:	it is NOT an unix filter.
author: Guo Jin (guojin@iss.nus.sg)
date:	Nov. 10, 1994
see also: the utf8 package by Ross Paterson <rap@doc.ic.ac.uk> ftped from
	ifcss.org: /software/unix/convert
*/

#include <stdio.h>
#include "utf.h"

#include <sys/types.h>
#include <sys/stat.h>
long filelength(file_name)
char *file_name;
{
        struct stat stbuf;
        stat(file_name, &stbuf);
        return stbuf.st_size;
}

int
main(argc, argv)
int argc;
char *argv[];
{
	FILE	*ifp, *ofp;
	long	len;
	int	i;
	unsigned short	unichar;

	if (argc != 3) {
		printf("usage: unitou8 <infile> <outfile>\n");
		exit(0);
	}

	ifp = fopen(argv[1], "rb");
	if (ifp == NULL) {
		printf("infile <%s> not found!\n", argv[1]);
		exit(0);
	}
	len = filelength(argv[1]);

	ofp = fopen(argv[2], "w");
	if (ofp == NULL) {
		printf("cannot open outfile <%s>!\n", argv[2]);
		exit(0);
	}

	for(i=0; i<len/sizeof(unsigned short); i++) {
		fread(&unichar, sizeof(unsigned short), 1, ifp);
		utf_putc(unichar, ofp);
	}

	fclose(ifp);
	fclose(ofp);

	return 0;
}
